package br.com.julian.projetolocadora.dto;

public class ListFilmeDTO extends BaseListDTO<FilmeDTO>{

}
