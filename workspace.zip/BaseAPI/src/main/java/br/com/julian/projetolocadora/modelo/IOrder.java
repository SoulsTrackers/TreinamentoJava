package br.com.julian.projetolocadora.modelo;

/**
 *
 * @author cleiton
 */
public interface IOrder {
    public String getCampo();
    public boolean isDesc();
}
